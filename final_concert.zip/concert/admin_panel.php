<!DOCTYPE html>
<html>
    <head>
        <title>Admin Panel</title>
        <link rel="icon" href="img/favicon.png">
        <style>
            body {
                background-image: url("img/concert1.png");
                font-family: Arial, sans-serif;
                background-color: #f4f4f4;
                margin: 0;
                padding: 0;
            }
            h1 {
                font-family: "Sacramento", cursive;
                text-align: center;
                color: white;
                margin-top: 50px;
                font-size: 36px;
            }
            .container {
                max-width: 600px;
                margin: 0 auto;
                text-align: center;
                padding: 20px;
            }
            .button-container {
                display: flex;
                flex-direction: column;
                align-items: center;
            }
            button {
                background-color: #007bff;
                color: white;
                border: none;
                padding: 10px 20px;
                text-align: center;
                text-decoration: none;
                display: inline-block;
                font-size: 16px;
                margin-top: 20px;
                cursor: pointer;
                border-radius: 5px;
            }
            button:hover {
                background-color: #0056b3;
            }
            button:active {
                background-color: #0056b3;
                transform: translateY(1px);
            }
            button a {
                color: white;
                text-decoration: none;
            }
            button a:hover {
                color: white;
            }
        </style>
    </head>
    <body>
        <h1>Welcome Admin!!</h1>
        <div class="button-container">
            <button><a href="manage_users.php">User Management</a></button><br>
            <button><a href="manage_tickets.php">Concert Management</a></button><br>
            <button><a href="manage_reviews.php">Review Management</a></button><br>
            <button><a href="logout.php">LOGOUT</a> </button>
        <br><br>
        </div>
    </body>
</html>