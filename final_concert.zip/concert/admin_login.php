<!DOCTYPE html>
<html>
    <head>
        <title>Admin Login</title>
        <link rel="icon" href="img/favicon.png">
        <style>
            body {
                margin: 0;
                padding: 0;
                font-family: sans-serif;
                position: relative;
                min-height: 100vh;
                padding-bottom: 50px;
                background-image: url("img/back.png");
                overflow:hidden;
            }
            .login-box {
                width: 300px;
                position: absolute;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
                color: white;
            }
            .login-box h2 {
                text-align: center;
                color: white;
                font-family: "Sacramento", cursive;
                font-size: 40px;
            }
            .login-box .textbox {
                position: relative;
                margin-bottom: 30px;
            }
            .login-box .textbox input {
                width: 100%;
                padding: 10px;
                background: #333;
                border: none;
                outline: none;
                color: white;
            }
            .login-box .btn {
                width: 100%;
                background: #333;
                border: none;
                padding: 10px;
                cursor: pointer;
                font-size: 18px;
                color: white;
                text-align: center;
            }
            .btn-primary {
                position: fixed;
                bottom: 0;
                left: 50%;
                transform: translateX(-50%);
                width: 50px; 
                height: 20px; 
                background-color: #2675ae;
                color: white;
                border: none;
                border-radius: 5px;
                cursor: pointer;
            }
        </style>
    </head>
    <body>
        <div class="login-box">
            <h2>Admin Login</h2>
            <form action="admin_login_process.php" method="post">
                <div class="textbox">
                    <input type="text" placeholder="Username" name="username" required>
                </div>
                <div class="textbox">
                    <input type="password" placeholder="Password" name="password" required>
                </div>
                <input class="btn" type="submit" value="Login">
            </form>
        </div>
        <a href="index.php">
            <button class="btn-primary">BACK</button>
        </a>
    </body>
</html>