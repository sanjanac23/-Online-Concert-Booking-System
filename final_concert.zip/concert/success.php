<!DOCTYPE html>
<html>
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>SYMPHONY SEATS</title>
		<?php require_once "bootstrap1.php";?>
		<style>
			a {
				color: #38acff;
			}
			.head{
				
				text-align: center;
			}
			.login{
				margin: 0 auto;
				width: 340px;
			}
			body {
				background-image: url(img/back3.png);
				background-size: cover;
				overflow: scroll;
				background-repeat: no-repeat;
				background-attachment: fixed;
				color: white;
			}
		</style>
	</head>
	<body>
	<div class="login" style="padding-top: 2%;">
		<form action="home1.php" style="border: 1px solid;">
			<div class="head">
				<h1><b>Awesome!</b></h1>
			</div>
			<div class="bd1" style="text-align: center; padding: 14%;">
				<p style="padding-bottom: 10%;">Your transaction has been successfull. <br>Check your email for booking details.</P>
				<a href="index.php">Click here to goto Home Page.</a>  
			</div>
		</form>
	</div>
	</body>
</html>