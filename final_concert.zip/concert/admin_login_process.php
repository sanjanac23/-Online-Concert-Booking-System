<?php
// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") 
{
    // Check if username and password are correct
    if ($_POST["username"] == "admin" && $_POST["password"] == "123") 
    {
        // Redirect to admin panel
        header("Location: admin_panel.php");
        exit();
    } 
    else 
    {
        // Display error message
        echo "<script>alert('Invalid username or password');</script>";
    }
}