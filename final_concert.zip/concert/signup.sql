-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 10, 2024 at 10:44 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `concerts`
--

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `name` varchar(50) NOT NULL PRIMARY KEY,
  `mail` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`name`, `mail`, `password`) VALUES
('Nishanth', 'nishanth@gmail.com', 'Nishanth@12'),
('Priyank', 'priyank88@gmail.com', 'Pk@123456'),
('Raj', 'raj12@gmail.com', 'Pk@123456'),
('Priya', 'priyag@gmail.com', 'pk@12345'),
('Sahil Ganeriwal', 'sahilganeriwal@hotmail.com', 'S@hil2726'),
('Vipul', 'vipulnagpal51@gmail.com', 'Vi$jgsvd4');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD UNIQUE KEY `UNIQUE` (`mail`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

-- Table structure for table `admin`
CREATE TABLE `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `admin`
INSERT INTO `admin` (`username`, `password`) VALUES
('admin', '12345');

-- Table structure for table `tickets`
CREATE TABLE `tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `concert_name` varchar(255) NOT NULL,
  `venue` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `tickets` 
INSERT INTO `tickets` (`id`, `date`, `concert_name`, `venue`) VALUES
(1, '2024-04-05', 'Vijay Prakash Concert', 'Bangalore Palace, Bangalore'),
(2, '2024-04-09', 'Rajesh Krishnan Concert', 'Jayamahal Palace, Bangalore'),
(3, '2024-04-20', 'Raghu Dixit Concert', 'BMS College, Bangalore'),
(4, '2024-04-25', 'Shreya Ghoshal Concert', 'Phoenix Marketcity, Bangalore'),
(5, '2024-04-30', 'Sonu Nigam Concert', 'Bhartiya Mall of Bangalore, Bangalore'),
(6, '2024-05-04', 'Arijit Singh Concert', 'Good Shepherd Auditorium, Bangalore'),
(7, '2024-05-10', 'K S Chitra Concert', 'Phoenix Marketcity, Bangalore'),
(8, '2024-05-16', 'Sunidhi Chauhan Concert', 'IISc, Bangalore'),
(9, '2024-05-24', 'Shankar Mahadevan Concert', 'Indira Nagar Club, Bangalore'),
(10, '2024-05-31', 'A R Rahman Concert', 'Mall of Asia, Bangalore'),
(11, '2024-06-06', 'Armaan Malik Concert', 'Phoenix Marketcity, Bangalore'),
(12, '2024-06-18', 'Kailash Kher Concert', 'Orion Mall, Bangalore'),
(13, '2024-06-23', 'Sanjith Hegde Concert', 'Nandi Link Grounds, Bangalore'),
(14, '2024-06-30', 'Atif Aslam Concert', 'Chowdiah Memorial Hall, Bangalore');


-- Table structure for table `ticket_types`
CREATE TABLE `ticket_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `ticket_types`
INSERT INTO `ticket_types` (`name`, `price`) VALUES
('General Admission', 4000.00),
('VIP', 9000.00);

-- Table structure for table `reviews`
CREATE TABLE `reviews` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(50) NOT NULL,
  `ticket_id` int(11) NOT NULL,
  `rating` int(11) NOT NULL,
  `comment` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_name` (`user_name`),
  KEY `ticket_id` (`ticket_id`),
  CONSTRAINT `reviews_ibfk_1` FOREIGN KEY (`user_name`) REFERENCES `user` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `reviews_ibfk_2` FOREIGN KEY (`ticket_id`) REFERENCES `tickets` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `reviews` 
INSERT INTO `reviews` (`user_name`, `ticket_id`, `rating`, `comment`) VALUES
('Nishanth', 1, 5, 'Smooth booking process, great seats, and an amazing concert experience overall!'),
('Priyank', 1, 4, 'Easy to use platform, but the ticket prices were a bit high for my liking.'),
('Raj', 2, 5, 'VIP treatment from start to finish, definitely worth the extra cost!'),
('Priya', 3, 3, 'Booking process was straightforward, but the concert lacked energy.'),
('Sahil Ganeriwal', 4, 5, 'The concert exceeded my expectations, Shreya Ghoshal was mesmerizing!'),
('Vipul', 5, 4, 'Great selection of concerts and easy booking process.'),
('Nishanth', 6, 5, 'Arijit Singh never disappoints, and the venue was perfect for the concert.'),
('Priyank', 7, 4, 'K S Chitra''s concert brought back nostalgic memories, great show!'),
('Raj', 8, 3, 'Sunidhi Chauhan seemed a bit off-key, but still enjoyable.'),
('Priya', 9, 5, 'Shankar Mahadevan rocked the stage with his energetic performance!'),
('Sahil Ganeriwal', 10, 5, 'A R Rahman is a living legend, an unforgettable experience.'),
('Vipul', 11, 4, 'Armaan Malik''s concert was intimate and soulful, loved every moment.'),
('Nishanth', 12, 5, 'Kailash Kher''s energy is infectious, had a blast at the concert!'),
('Priyank', 13, 4, 'Sanjith Hegde''s concert was a pleasant surprise, great talent.'),
('Raj', 14, 5, 'Atif Aslam''s concert was magical, a night to remember.');