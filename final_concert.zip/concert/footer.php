<div class="footer">
  <div class="w-container">
    <a class="footer-link w-inline-block" href="https://www.facebook.com" target="_blank">
      <img id="fot" src="http://uploads.webflow.com/560eb94ab52962bd77dfcf14/56152593b79d0bd36c914521_social-03-white.svg" width="23">
    </a>
    <a class="footer-link w-inline-block" href="https://twitter.com" target="_blank">
      <img src="http://uploads.webflow.com/560eb94ab52962bd77dfcf14/561525930c0daecc11081899_social-18-white.svg" width="23">
    </a>
    <a class="footer-link w-inline-block" href="https://www.youtube.com" target="_blank">
      <img src="http://uploads.webflow.com/560eb94ab52962bd77dfcf14/56152593cb7d6c033386b191_social-16-white.svg" width="23">
    </a>
    <div class="footer-text"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">This site uses cookies. By continuing to browse the site you are agreeing to our use of cookies.&nbsp;</font></font></div>
  </div>
</div>