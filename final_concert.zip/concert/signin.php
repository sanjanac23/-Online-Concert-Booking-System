<?php
session_start();
$connect_mysql = mysqli_connect("localhost", "root", "", "concerts");
if (!$connect_mysql) {
    die("Connection Failed: " . mysqli_connect_error());
}
if (isset($_POST['mail']) && isset($_POST['pwd'])) {
    $mail = mysqli_real_escape_string($connect_mysql, $_POST['mail']);
    $password = mysqli_real_escape_string($connect_mysql, $_POST['pwd']);
    $result = mysqli_query($connect_mysql, "SELECT * FROM user WHERE mail='$mail'");
    if (!$result) {
        die("Query Failed: " . mysqli_error($connect_mysql));
    }
    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        if (password_verify($password, $row['password'])) {
            $_SESSION["mail"] = $row['mail'];
            $_SESSION['start'] = time();
            $_SESSION['expire'] = $_SESSION['start'] + (20 * 3660);
            setcookie('mail', $_POST['mail'], time() + 3660);
            header('Location: index.php');
            exit();
        }
    }
}
$message = "Invalid Username or Password!";
header("Location: Signin.php?msg=" . urlencode($message));
exit();
?>