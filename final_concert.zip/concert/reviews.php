<?php
$connection = mysqli_connect("localhost", "root", "", "concerts");
if (!$connection) {
    die("Database connection failed: " . mysqli_connect_error());
}
// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_name = $_POST['user_name'];
    $rating = $_POST['rating'];
    $comment = $_POST['comment'];
    $ticket_id = $_POST['ticket_id']; 
    // Insert review into the database
    $query = "INSERT INTO reviews (user_name, rating, comment, ticket_id) VALUES ('$user_name', '$rating', '$comment', '$ticket_id')";
    $result = mysqli_query($connection, $query);
    if (!$result) {
        die("Failed to submit review: " . mysqli_error($connection));
    }
}
// Retrieve reviews from the database
$query = "SELECT * FROM reviews";
$result = mysqli_query($connection, $query);
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Reviews</title>
        <link rel="icon" href="img/favicon.png">
        <style>
            body {
                background-image: url("img/back1.png");
                background-attachment: fixed;
                background-repeat: no-repeat;
                background-size: cover; /
                font-family: Arial, sans-serif;
                margin: 20px;
                padding: 20px;
                background-color: rgba(244, 244, 244, 0.8); 
                justify-content: center;
                align-items: center;
                height: 100vh;
            }
            h1 {
                font-size:80px;
                margin-bottom: 20px;
                text-align:center;
                color:white;
                font-family: "Sacramento", cursive;
            }
            .review-container {
                display: flex;
                flex-wrap: wrap;
                justify-content: space-around;
                gap: 20px;
            }
            .review-box {
                color: black;
                width: 30%;
                margin-bottom: 20px;
                padding: 20px;
                background-color: rgba(255, 255, 255, 0.8);
                box-sizing: border-box;
                border-radius: 10px;
                box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
                text-align: center;
            }
            label {
                display: block;
                margin-bottom: 5px;
            }
            input[type="submit"] {
                padding: 5px 10px;
                background-color: #007bff;
                color: white;
                border: none;
                cursor: pointer;
            }
            input[type="submit"]:hover {
                background-color: #0056b3;
            }
            .review-box:nth-child(3n+1) {
                margin-left: 0;
            }
            .review-box:nth-child(3n+3) {
                margin-right: 0;
            }
            form {
                margin: 0 auto;
                max-width: 500px;
                padding: 20px;
                background-color: rgba(255, 255, 255, 0.8);
                border-radius: 10px;
                box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
                text-align: center;
                margin-top:20px;
            }
            form input,
            form textarea {
                width: calc(100% - 10px);
                padding: 5px;
                margin-bottom: 10px;
                border: 1px solid #ddd;
                border-radius: 5px;
            }
        </style>
    </head>
    <body>
    <h1>Reviews</h1>
    <div class="review-container">
        <?php while ($row = mysqli_fetch_assoc($result)): ?>
            <div class="review-box">
                <p><strong>User:</strong> <?php echo $row['user_name']; ?></p>
                <p><strong>Rating:</strong> <?php echo str_repeat("★", $row['rating']) . str_repeat("☆", 5 - $row['rating']); ?></p>
                <p><strong>Comment:</strong> <?php echo $row['comment']; ?></p>
            </div>
        <?php endwhile; ?>
    </div>
    <form method="post">
        <h3>Your Review:</h3>
        <label for="user_name">Your Name:</label>
        <input type="text" id="user_name" name="user_name" placeholder="Username" required>
        <label for="rating">Rating:</label>
        <input type="number" id="rating" name="rating" min="1" max="5" placeholder="Rating" required>
        <label for="comment">Comment:</label>
        <textarea id="comment" name="comment" placeholder="Comments" required></textarea>
        <label for="ticket_id">Ticket ID:</label>
        <input type="text" id="ticket_id" name="ticket_id" placeholder="Ticket ID" required>
        <input type="submit" value="Submit Review">
    </form>
    <a href="index.php">
        <button class="btn-primary">BACK</button>
    </a>
    </body>
</html>