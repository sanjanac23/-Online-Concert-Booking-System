<?php
$connection=mysqli_connect("localhost","root","","concerts");
// Handling review deletion
if (isset($_POST['delete_review'])) {
    $review_id = $_POST['review_id'];
    $delete_query = "DELETE FROM reviews WHERE id = $review_id";
    mysqli_query($connection, $delete_query);
}
// Handling review reply submission
if (isset($_POST['reply_review'])) {
    $review_id = $_POST['review_id'];
    $reply = $_POST['reply'];
    // Display a message
    echo "<script>alert('Review replied successfully');</script>";
}
// Fetch all reviews
$sql = "SELECT * FROM reviews";
$result = mysqli_query($connection, $sql);
?>
<html>
    <head>
        <title>Review Management</title>
        <link rel="icon" href="img/favicon.png">
        <style>
            body {
            background-image: url("img/party2.jpg");
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f4f4f4;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            min-height: 100vh; 
        }
        .container {
            max-width: 800px;
            width: 100%;
            text-align: center;
        }
        h2 {
            color: #333;
            font-family: "Arial Black", sans-serif;
            font-size: 28px;
            margin-bottom: 20px;
        }
        table {
            margin: 20px auto; 
            width: 90%; 
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        tr {
            background-color: #f2f2f2;
        }
        .btn-primary {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 5px 10px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 12px;
            cursor: pointer;
            border-radius: 5px;
        }
        .btn-primary:hover {
            background-color: #0056b3;
        }
        .btn-primary:active {
            background-color: #0056b3;
            transform: translateY(1px);
        }
        </style>
    </head>
    <body>
    <h2>Review Management</h2>
    <table border="1">
        <tr>
            <th>User</th>
            <th>Rating</th>
            <th>Comment</th>
            <th>Action</th>
        </tr>
        <?php while($row = mysqli_fetch_assoc($result)): ?>
        <tr>
            <td><?php echo $row['user_name']; ?></td>
            <td><?php echo $row['rating']; ?></td>
            <td><?php echo $row['comment']; ?></td>
            <td>
                <form method="post">
                    <input type="hidden" name="review_id" value="<?php echo $row['id']; ?>">
                    <textarea name="reply" placeholder="Reply..."></textarea><br>
                    <button type="submit" class="btn-primary" name="reply_review">Reply</button>
                    <button type="submit" class="btn-primary" name="delete_review">Delete</button>
                </form>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
    <a href="admin_panel.php">
        <button class="btn-primary">BACK</button>
    </a>
    </body>
</html>