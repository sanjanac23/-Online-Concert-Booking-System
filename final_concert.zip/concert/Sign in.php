<?php
session_start();
$connect_mysql = mysqli_connect("localhost", "root", "", "concerts");
if (!$connect_mysql) {
    die("Connection Failed: " . mysqli_connect_error());
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $mail = mysqli_real_escape_string($connect_mysql, $_POST['mai']);
    $password = mysqli_real_escape_string($connect_mysql, $_POST['pwd']);
    $result = mysqli_query($connect_mysql, "SELECT * FROM user WHERE mail='$mail'");
    if (!$result) {
        die("Query Failed: " . mysqli_error($connect_mysql));
    }
    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        if (password_verify($password, $row['password'])) {
            $_SESSION["mail"] = $row['mail'];
            $_SESSION['start'] = time();
            $_SESSION['expire'] = $_SESSION['start'] + (20 * 3660);
            if (isset($_POST['remember'])) {
                setcookie('mail', $row['mail'], time() + 3660);
                setcookie('password', $password, time() + 3660);
            } else {
                setcookie('mail', '', time() - 3600);
                setcookie('password', '', time() - 3600);
            }
            header('Location: index.php');
            exit();
        } else {
            $message = "Invalid Password!";
        }
    } else {
        $message = "Invalid Username!";
    }
    header("Location: Signin.php?msg=" . urlencode($message));
    exit();
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>SYMPHONY SEATS</title>
        <?php require_once "bootstrap1.php"; ?>
        <style>
            a {
                color: #2675ae;
                text-decoration: none;
            }
            .new {
                margin-top: 16px;
                padding: 15px 20px;
                text-align: center;
            }
            .head {
                text-align: center;
            }
            .login {
                margin: 0 auto;
                width: 340px;
            }
            label {
                color: white;
            }
            .bd1 {
                background-color: transparent;
                font-size: 14px;
                padding: 20px;
            }
            .btn-primary {
                background-color: #2675aed9;
            }
            form label {
                display: block;
                margin-bottom: 7px;
            }
            input {
                margin-bottom: 15px;
                margin-top: 5px;
            }
            body {
                background-image: url("img/back4.png");
                background-size: auto;
                background-repeat: no-repeat;
                color: white;
            }
            .label-link {
                margin-left: 7em;
            }
            .form-control {
                background-color: #ffffffc2;
            }
            p {
                color: #ffffffba;
            }
            @keyframes shake {
                10%,
                90% {
                    transform: translate3d(-1px, 0, 0);
                }
                20%,
                80% {
                    transform: translate3d(2px, 0, 0);
                }
                30%,
                50%,
                70% {
                    transform: translate3d(-4px, 0, 0);
                }
                40%,
                60% {
                    transform: translate3d(4px, 0, 0);
                }
            }
            .inc {
                animation-name: shake;
                animation-duration: 1s;
                text-align: center;
                color: red;
            }
        </style>
    </head>
    <body>
        <div class="login">
            <form action="tour(cor).php" method="POST">
                <div class="head">
                    <h1><b>Sign In</b></h1>
                </div>
                <div class="bd1">
                    <?php
                    if (isset($_REQUEST["msg"])) {
                        echo "<h4 class='inc'>" . $_REQUEST["msg"] . "</h4>";
                    }
                    ?>
                    <label for="login">Email</label>
                    <input type="email" name="mai" id="login_field" class="form-control input-block" tabindex="1" autofocus="autofocus" required placeholder="Enter Email ID" value="<?php echo isset($_COOKIE['mail']) ? $_COOKIE['mail'] : ''; ?>">
                    <label for="password">Password</label>
                    <input type="password" name="pwd" id="password" placeholder="Enter Password" class="form-control form-control input-block" tabindex="2" required value="<?php echo isset($_COOKIE['password']) ? $_COOKIE['password'] : ''; ?>">
                    <label><input type="checkbox" name="remember"> Remember me</label>
                    <input type="submit" name="commit" value="Sign in" tabindex="3" class="btn btn-primary btn-block" data-disable-with="Signing in…">
                </div>
            </form>
            <p class="new">
                "New to site"<i>
                    <a data-ga-click="Sign in, switch to sign up" href="Signup.php" style="color: white;">Create an account</a></i><br>OR<br><i>
                    <a href="index.php" style="color: white;">Skip Sign In</a></i>
            </p>
        </div>
    </body>
</html>