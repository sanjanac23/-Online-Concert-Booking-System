<?php
$connection=mysqli_connect("localhost","root","","concerts");
// Add ticket
if(isset($_POST['add_submit'])) {
    $date = $_POST['date'];
    $concert_name = $_POST['concert_name'];
    $venue = $_POST['venue'];
    $sql = "INSERT INTO tickets (date, concert_name, venue) VALUES ('$date', '$concert_name', '$venue')";
    mysqli_query($connection, $sql);
}
// Edit ticket
if(isset($_POST['edit_submit'])) {
    $id = $_POST['id'];
    $date = $_POST['date'];
    $concert_name = $_POST['concert_name'];
    $venue = $_POST['venue'];
    $sql = "UPDATE tickets SET date='$date', concert_name='$concert_name', venue='$venue' WHERE id='$id'";
    mysqli_query($connection, $sql);
}
// Delete ticket
if(isset($_POST['delete_submit'])) {
    $id = $_POST['id'];
    $sql = "DELETE FROM tickets WHERE id='$id'";
    mysqli_query($connection, $sql);
}
// Fetch all tickets
$sql = "SELECT * FROM tickets";
$result = mysqli_query($connection, $sql);
?>
<html>
    <head>
        <title>Manage Concerts</title>
        <link rel="icon" href="img/favicon.png">
        <style>
            body {
                background-image: url("img/download.png");
                background-attachment: fixed;
                background-size: cover; 
                background-position: center; 
                margin: 0; 
                padding: 0; 
                font-family: Arial, sans-serif;
                background-color: #f8f9fa;
                margin: 0;
                padding: 0;
            }
            h2 {
                text-align: center;
                margin-top: 20px;
                color: white;
                font-family: 'Playfair Display',serif;
                font-size:40px;
            }
            h3 {
                margin-top: 20px;
                color: white;
                text-align: center;
                font-size:20px;
            }
            form {
                margin-bottom: 20px;
                padding: 10px;
                background-color: white;
                border: 1px solid #ccc;
                border-radius: 5px;
                width: 50%;
                margin: 0 auto;
            }
            form input[type="text"],
            form input[type="submit"] {
                margin: 5px 0;
                padding: 8px;
                width: 100%;
                box-sizing: border-box;
                border: none; 
                border-radius: 3px;
                outline: none; 
            }
            form input[type="submit"] {
                background-color: #007bff;
                color: white;
                cursor: pointer;
            }
            form input[type="submit"]:hover {
                background-color: #0056b3;
            }
            table {
                width: 80%;
                margin: 0 auto;
                border-collapse: collapse;
                font-size: 14px; 
                background-color:white;
            }
            table, th, td {
                border: 2px solid #ccc;
            }
            th, td {
                padding: 8px; 
                text-align: left;
            }
            th {
                background-color: #007bff;
                color: white;
            }
            td form {
                display: inline;
                outline:none;
                border-style:none;
            }
            button {
                background-color: #007bff;
                color: white;
                border: none;
                padding: 8px 20px;
                text-align: center;
                text-decoration: none;
                display: inline-block;
                font-size: 14px;
                margin-top: 5px;
                cursor: pointer;
                border-radius: 5px;
                outline:none;
            }
            button:hover {
                background-color: #0056b3;
            }
            button:active {
                background-color: #0056b3;
                transform: translateY(1px);
            }
            button a {
                color: white;
                text-decoration: none;
            }
            td form {
                display: inline;
                outline:none;
                border-style:none;
                margin: 0; 
                padding: 0; 
            }
            .del {
                background-color: transparent; 
                color: #007bff; 
                border: none; 
                padding: 0; 
                font-size: 14px; 
                cursor: pointer;
            }
        </style>
    </head>
    <body>
    <h2>Add/Edit/Delete Concert</h2>
    <!-- Adding Ticket Form -->
    <h3>Add Concert</h3>
    <form action="" method="post">
        <input type="text" name="date" placeholder="Date" required><br>
        <input type="text" name="concert_name" placeholder="Concert Name" required><br>
        <input type="text" name="venue" placeholder="Venue" required><br>
        <input type="submit" name="add_submit" value="Add Concert">
    </form>
    <!-- Display Tickets -->
    <h3>List of Concerts</h3>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Date</th>
            <th>Concert Name</th>
            <th>Venue</th>
            <th>Edit</th>
            <th>Delete</th>
        </tr>
        <?php while($row = mysqli_fetch_assoc($result)): ?>
        <tr>
            <td><?php echo $row['id']; ?></td>
            <td><?php echo $row['date']; ?></td>
            <td><?php echo $row['concert_name']; ?></td>
            <td><?php echo $row['venue']; ?></td>
            <td>
                <button onclick="editTicket(<?php echo $row['id']; ?>, '<?php echo $row['date']; ?>', '<?php echo $row['concert_name']; ?>', '<?php echo $row['venue']; ?>')">Edit</button>
            </td>
            <td>
                <form action="" method="post" class="del">
                    <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                    <input type="submit" name="delete_submit" value="Delete">
                </form>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
    <script>
    function editTicket(id, date, concertName, venue) {
        var newDate = prompt("Enter new date:", date);
        var newConcertName = prompt("Enter new concert name:", concertName);
        var newVenue = prompt("Enter new venue:", venue);
        if (newDate !== null && newConcertName !== null && newVenue !== null) {
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            xhr.onreadystatechange = function() {
                if (this.readyState === XMLHttpRequest.DONE && this.status === 200) {
                    location.reload();
                }
            };
            xhr.send("edit_submit=true&id=" + id + "&date=" + newDate + "&concert_name=" + newConcertName + "&venue=" + newVenue);
        }
    }
    </script>
    <a href="admin_panel.php">
        <button class="btn-primary">BACK</button>
    </a>
    </body>
</html>